#------------------------------------------------------------------------------------
#
#   step3.py for <Global_fold_split.R>
#   version: 1.0
#   8th March 2017
#   Eunji Kim
#
#-----------------------------------------------------------------------------------

###This is the last step of Global_fold_split.R ###
###This code reads output files from step2.R, generates new famfiles####

import glob,sys,csv,re,random,os
os.mkdir('output_fam')
random.seed(0)  ## seed is fixed for consistent output.

#read famfile_to_caseID
famfile_to_caseID={}
for famfile,caseID in csv.reader(open("case.csv")):
  famfile_to_caseID[famfile]=caseID
#read famfile_to_specontID
famfile_to_specontID={}
for famfile,specontID in csv.reader(open("specont.csv")):
  famfile_to_specontID[famfile]=specontID
#read cont_share_dictionary: pair, element <------------------
famfiles_to_sharedcontID={}
for famfiles,sharedcontID in csv.reader(open("sharedcont.csv")):
  famfiles_to_sharedcontID[famfiles]=sharedcontID
#read numbers of split controls (output of step 2.)
nsplitcont_file=open('shared.txt','r')
nsplitcont=nsplitcont_file.readlines()
nsplitcont_file.close()

#===Randomly split the ID of the overlapping control into the optimal ratio obtained in step2==#
famfile_to_splitID=dict()
casefamfiles=famfile_to_caseID.keys()
nfamfiles=len(casefamfiles)
element=0
for famfiles,sharedcontID in famfiles_to_sharedcontID.items():
  random.shuffle(eval(sharedcontID)) ## str -> random list
  nsplit_per_group=eval(nsplitcont[element])
  start=0
  end=0
  for i in range(nfamfiles): 
    end=int(nsplit_per_group[i])+end
    splitID_perfamfile=eval(sharedcontID)[start:end]
    start=end
    casefamfile=casefamfiles[i]
    if(casefamfile in famfile_to_splitID.keys()):
      famfile_to_splitID[casefamfile].append(splitID_perfamfile)
    else:
      famfile_to_splitID[casefamfile]=splitID_perfamfile
  element+=1

#===============Create new independent famfiles with the updated information================#

j=0
nstudy=0
famfiles=glob.glob('./*.fam')

for filename in famfiles:
  nstudy+=1
  data=open(filename,"r").readlines()
  updatedfilename=(str(filename).strip("./"))
  updatedfile=open(os.path.join('output_fam',"fold_%s" %updatedfilename),"w") 
  for eachline in data:
    Type=eachline.split()
    fid,iid,phe=Type[0],Type[1],Type[5]
    ID=fid+" "+iid
    ##affected : case
    if (phe=='2'):
      for casefamfile,caseID in famfile_to_caseID.items():
        if filename==casefamfile:
          updatekey=eval(caseID)
          if ID in updatekey:
            updatedfile.write(eachline)
    ##not affected : control
    elif (phe=='1'):
      for specont_famfile,specontID in famfile_to_specontID.items():
        if str(filename)==specont_famfile:
          updatekeycont=eval(specontID)
          if ID in updatekeycont:
            updatedfile.write(eachline)
        #shared _ seperated controls
      for splitcont_famfile,splitID in famfile_to_splitID.items(): 
        splitID=str(splitID)
        if filename==splitcont_famfile:
          if ID in splitID:
            updatedfile.write(eachline)
updatedfile.close()
print("Done, you can check new FAM files")
