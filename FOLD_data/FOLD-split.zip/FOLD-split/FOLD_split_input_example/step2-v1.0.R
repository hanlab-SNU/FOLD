#---------------------------------------------------------------------------------
#
#   step2.R for <Global_fold_split.R>
#   version: 1.0
#   8th March 2017
#   Eunji Kim
#
#----------------------------------------------------------------------------------

###this code performs maximization and finds the optimal splitting numbers for overlapping controls

##please uncomment if Rsolnp is not installed
#install.packages("Rsolnp")
library("Rsolnp")

#================read step1 output files: they are in current directory================#
indicator_mat=read.csv("ind_mat.csv",sep=",",header=F)
indicator_mat=t(indicator_mat)
cat("Indicator matrix reads well...:\n")
print(indicator_mat)
nfamfiles=nrow(indicator_mat)-1
nsubgroup=ncol(indicator_mat)
#ncase
ncasefile=read.csv("ncase.csv",sep=",",header=F)
ncase=as.numeric(ncasefile[,2])
#nspecont
nspecontfile=read.csv("nspecont.csv",sep=",",header=F)
nspecont=as.numeric(nspecontfile[,2])
#extract nshared from last row
nsharedcont=indicator_mat[nrow(indicator_mat),]
indicator_mat=indicator_mat[1:nfamfiles,]
#==================main function: returns total sum of effective numbers==================#
getsumneff=function(splitcont){ 
    component=1 ## iterates all nonzero elements in indicator matrix
    assignnsplit=matrix(0,nrow=nfamfiles,ncol=nsubgroup) ## recover matrix from vector
    for(eachsubgroup in 1:nsubgroup){

        if(length(indicator_mat)==nfamfiles){
         subgr_famfiles=which(indicator_mat==1)
        }
        else{
        subgr_famfiles=which(indicator_mat[,eachsubgroup]==1)
        }
        for(i in subgr_famfiles){
            assignnsplit[i,eachsubgroup]=splitcont[component]
            component=component+1
        }
    }
    sumneff=0
    for(famfile in 1:nfamfiles){
        splitcont_update=sum(assignnsplit[famfile,])
        neff=(4*ncase[famfile]*(nspecont[famfile]+splitcont_update))/(ncase[famfile]+nspecont[famfile]+splitcont_update)
        sumneff=sumneff+neff
    }
    return(-sumneff) ## negative for maximization.
}

#=================generate lower and upper boundary for maxneff function============#
maxnsplit=NULL
for(eachsubgroup in 1:nsubgroup){
   if(length(indicator_mat)==nfamfiles){
      subgr_length=length(which(indicator_mat==1))
   }
   else{
      subgr_length=length(which(indicator_mat[,eachsubgroup]==1))
    }

    maxs=rep(nsharedcont[eachsubgroup],subgr_length)
    maxnsplit=c(maxnsplit,maxs)
}
##lower,upper bound of parameters
maxneffUB=maxnsplit
maxneffLB=rep(0,length(maxnsplit))

#======================constaining function: returns sums of shared controls============================#
get_nshared_subgr=function(splitcont){ 
    nshared_subgr=rep(0,nsubgroup)
    component=1
    for(eachsubgroup in 1:nsubgroup){
        if(length(indicator_mat)==nfamfiles){
         subgr_famfiles=which(indicator_mat==1)
        }
        else{
        subgr_famfiles=which(indicator_mat[,eachsubgroup]==1)
        }
        for(i in subgr_famfiles){
            nshared_subgr[eachsubgroup]=nshared_subgr[eachsubgroup]+splitcont[component]  
            component=component+1
        }
    }
    return(nshared_subgr)   
}

#=======================optimal parameters==========================================#
smart.round <- function(x) { ## for integer rounding while preserving sum
  y <- floor(x)
  indices <- tail(order(x-y), round(sum(x)) - sum(y))
  y[indices] <- y[indices] + 1
  y
}
optpar=gosolnp(pars=NULL,fixed=NULL,fun=getsumneff,LB=maxneffLB,UB=maxneffUB,eqfun=get_nshared_subgr,eqB=nsharedcont,n.restarts=5)
optimal_nsplit=optpar$pars
assignnsplit=matrix(0,nrow=nfamfiles,ncol=nsubgroup)  
component=1
for(eachsubgroup in 1:nsubgroup){
        if(length(indicator_mat)==nfamfiles){
         subgr_famfiles=which(indicator_mat==1)
        }
        else{
        subgr_famfiles=which(indicator_mat[,eachsubgroup]==1)
        }

    for(i in subgr_famfiles){
        assignnsplit[i,eachsubgroup]=optimal_nsplit[component]
        component=component+1
    }
}
cat("Results before rounding...\n")
print(t(assignnsplit))
assignnsplit=apply(assignnsplit, 2, smart.round)
cat("Results after rounding...\n")
print(t(assignnsplit))

write.table(t(assignnsplit),file="shared.txt",quote=F, col.names=F, row.names=F,sep=",")
