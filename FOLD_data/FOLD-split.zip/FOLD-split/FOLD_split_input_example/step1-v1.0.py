#------------------------------------------------------------------------------------------------------#
#
#   step1.py for <Global_fold_split.R>
#   version: 1.0
#   8th March 2017
#   Eunji Kim
#
#------------------------------------------------------------------------------------------------------#

### this code reads and analyzes overlapping subjects between multiple FAM files, and generates files for step 2. 
### input: FAM files are current directory.

import glob,sys,csv,re

## read all FAM files from the current directory.
famfiles = glob.glob('./*.fam')

## prepare dictionaries.
contID_to_famfile=dict()  ## from individual control ID to famfile
famfile_to_caseID=dict() ## from famfile to caseID
famfile_to_contID=dict() ## fromf famfile to contID
famfile_to_specontID=dict() ## from famfile to specontID
famfile_to_sharedcontID=dict() ## from famfile to sharedID
famfile_to_ncase=dict() ## from famfile to number of cases in each famfile 
famfile_to_nspecont=dict() ## from famfile to number of case-specific controls in the famfiles.
famfile_to_nsharedcont=dict() ## from famfile to number of shared controls in the famfiles.
famfile_to_filenumber=dict()

#====================read famfiles and categorize IDs accoring to their phenotypes=======================#
nstudy=0
for filename in famfiles:
  data=open(filename,"r").readlines()
  nstudy+=1
  famfile_to_filenumber[filename]=nstudy
  for eachline in data:
    Type=eachline.split()
    fid,iid,phe=Type[0],Type[1],Type[5]
    # assign new ID using family and individual IDs.
    ID = fid+" "+iid
    ##affected : case 
    if phe=='2':
      if filename in famfile_to_caseID:
        famfile_to_caseID[filename].append(ID)
      else:
        famfile_to_caseID[filename]=[ID]
    ##not affected : control 
    elif phe=='1':
      if ID in contID_to_famfile:
        contID_to_famfile[ID].append(filename)  
      else:
        contID_to_famfile[ID]=[filename]
  famfile_to_ncase[filename]=len(famfile_to_caseID[filename])

#================reverse the dictonary order to famfile:contIDs from contIDs:famfiles============================#
for contID,famfls in contID_to_famfile.items():
  famflsstr = str(famfls) ##change type of famfls from list to string in order to use it as a key
  if famflsstr in famfile_to_contID:
    famfile_to_contID[famflsstr].append(contID)
  else:
    famfile_to_contID[famflsstr]=[contID]
  #shared control IDs
  if len(famfls) > 1:
    if famflsstr in famfile_to_sharedcontID:
      famfile_to_sharedcontID[famflsstr].append(contID)
    else:
      famfile_to_sharedcontID[famflsstr]=[contID]
  #study_specific control IDs
  else:
    for eachfile in famfile_to_caseID:
      famfile=famflsstr.replace('[','').replace(']','')
      famfile=famfile[1:len(famfile)-1]
      if eachfile==famfile:
        if eachfile in famfile_to_specontID:
          famfile_to_specontID[eachfile].append(contID)
        else:
          famfile_to_specontID[eachfile]=[contID]
      else:
        if eachfile not in famfile_to_specontID:
          famfile_to_specontID[eachfile]=[]

if len(famfile_to_specontID)==0:
  for eachfile in famfile_to_caseID:
    famfile_to_specontID[eachfile]=[]
       
#================number of study_specific controls for each FAMfile========================================#
for famfls,specontID in famfile_to_specontID.items():
  famfile_to_nspecont[famfls]=len(specontID)

#==============================indicator_matrix============================================================#
#each column represents a subgroup of controls that are shared by a specific combination of FAMfiles.
#the rows represent FAMfiles.
#element 1/0 in this matrix indicates whether a control group is shared by a FAMfile. 
#the last additional row indicates the number of overlapping controls in each column.

nrow,ncol=nstudy+1,len(famfile_to_sharedcontID)
indicator_matrix=[[0 for x in range(nrow)] for y in range(ncol)]
subgroupnum=0
for famflsstr,sharedcontID in famfile_to_sharedcontID.items():
  famfls=eval(famflsstr) #recover list from string
  for famfl in famfls:
    famindex=famfile_to_filenumber[famfl]-1
    indicator_matrix[subgroupnum][famindex]=1
  indicator_matrix[subgroupnum][nrow-1]=len(sharedcontID)
  subgroupnum+=1

#================================save Famfiles and IDs in .csv============================================#
#case
casefile=open("case.csv","w")
case_record=csv.writer(casefile)
for famfile,caseID in famfile_to_caseID.items():
  case_record.writerow([famfile,caseID])
casefile.close()
#specont
specontfile=open("specont.csv","w")
specont_record=csv.writer(specontfile)
for famfile,ID in famfile_to_specontID.items():
  specont_record.writerow([famfile,ID])
specontfile.close()
#sharedcont
sharedcontfile=open("sharedcont.csv","w")
sharedcont_record=csv.writer(sharedcontfile)
for famfile,ID in famfile_to_sharedcontID.items():
  sharedcont_record.writerow([famfile,ID])
sharedcontfile.close()
#Indicator matrix
indicator_matfile=open("ind_mat.csv","w")
indicator_record=csv.writer(indicator_matfile)
for eachrow in indicator_matrix:
  indicator_record.writerow(eachrow)
indicator_matfile.close()
#ncase
ncasefile=open("ncase.csv","w")
ncase_record=csv.writer(ncasefile)
for famfile,ncase in famfile_to_ncase.items():
  ncase_record.writerow([famfile,ncase])
ncasefile.close()
#nspecont
nspecontfile=open("nspecont.csv","w")
nspecont_record=csv.writer(nspecontfile)
for famfile,nspecont in famfile_to_nspecont.items():
  nspecont_record.writerow([famfile,nspecont])
nspecontfile.close()
