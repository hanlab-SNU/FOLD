
######################################################
# fold-input.py
#  xxxx Seperate control and case samples into two different types, study-specific and shared.
#  xxxx fold input consideres both case and control overlapping
#  xxxx Generates input files ***.fold.fam 
# Eunji Kim (2016)
## Usage: read all.fam files in c("*.fam","**.fam",...etc)
## Additional information is available in manual
######################################################

FOLD.input <- function(famfiles) { #data: all fam files  
	#function find duplicate between different groups
	findDuplicate <- function (datas, detectcol) {
		datacols <- setdiff(names(datas), detectcol)
		sortorder <- do.call(order, datas)
		datas <- datas[sortorder,]
		dupWithin <- duplicated(datas)
		Dup = rep(NA, nrow(datas))
		#only Dup between datas
		Dup[!dupWithin] <- duplicated(datas[!dupWithin,datacols])
		Dup[!dupWithin] <- duplicated(datas[!dupWithin,datacols], fromLast=TRUE) | Dup[!dupWithin]
		index <- !is.na(Dup)
		Values <- c(NA, Dup[index])
		Dup[sortorder] <- Values[cumsum(index)+1]
		return(Dup)
	}	

	ndata <- length(famfiles)
	for (i in ndata:2){
		allcomb =  combn((ndata:1),i)
		nlist = ncol(allcomb)
		for (j in 1:nlist){                   
			seqlist = allcomb[,j]
			nelement = length(seqlist)
			for (k in 1:nelement){
				name = as.matrix(read.table(famfiles[seqlist[k]], header= FALSE))	
				cont = name[which(name[,6]==1),]
				contname = cont[,1:2]
				if(k==1){
					oldcont= contname
				}
				if(k!=1){
					sharecont = merge(contname,oldcont)
					oldcont = sharecont
				}
			}
			if(i == ndata){
				contsharelist <- (list(seqlist,sharecont))
				recordcont = sharecont			
			}
			#finish recording allcomb with ith digit
			else {  
				if(nrow(sharecont)==0){next}
				else{
					if(nrow(recordcont)==0){
						recordcont = sharecont
						contsharelist <- (list(seqlist,sharecont))
					}
					else{
						recordcont=recordcont[,!(names(recordcont) %in% "coder")]
						names(recordcont)=names(sharecont)=c("fid","iid")
						recordcont$coder  <- "predefind"
						sharecont$coder <- "newpair"
						dfcont <- rbind(recordcont,sharecont)				
						dfcont <- dfcont[,c("fid","iid","coder")]				
						dupRowscont <- findDuplicate(dfcont,"coder")				
						spesharecont=(cbind(dfcont,dup=!dupRowscont))
						spesharecont=(spesharecont[which(spesharecont$dup=="TRUE"),])
						spesharecont=(spesharecont[which(spesharecont$coder=="newpair"),])
						spesharecont=spesharecont[,!(names(spesharecont) %in% "dup")]
						recordcont = unique(rbind(recordcont,spesharecont))
						spesharecont=spesharecont[,!(names(spesharecont) %in% c("coder"))]
						recordcont=recordcont[,!(names(recordcont) %in% c("coder"))]
						contsharelist <- cbind(contsharelist,(list(seqlist,spesharecont)))}
				}
			}	
		}
		sharecont = 0
	}

######## Step 1. finish specifying shared list for study pairs
	for (i in 1:ndata){
		oridata = as.matrix(read.table(famfiles[i], header= FALSE))
		case = oridata[which(oridata[,6]==2),]
		contseqnpair <- seq(1,length(contsharelist),1)
		for (j in contseqnpair){
			for (jj in contseqnpair){
				if(i %in% contsharelist[[jj]]){
					nstartcont = jj
					break
				}
			}
			if(i %in% contsharelist[[j]]){
				if(nrow(contsharelist[[j+1]])>0){
					result = NULL
					inside = (contsharelist[[j+1]])
					for(ii in 1:length(contsharelist[[j]])){
						result = paste(result,contsharelist[[j]][ii])
					}
					
					
					if(nrow(inside)==0){
						print("all control samples are specific")
					}
				       else{
				 
					newdata = oridata[(paste(oridata[,1],oridata[,2]) %in% paste(inside[,1],inside[,2])),] 
	
					write.table(rbind(case,newdata), file=paste("shared-",i,"-pair-",result,"-study-fold.ped",sep=""), quote=F, col.names=F, row.names=F)
										
				       }
				}

				if(j==nstartcont){
					contcum = contsharelist[[j+1]]
				}
				else {  
					names(contcum)=c("fid","iid")
					contcum = rbind(contcum,contsharelist[[j+1]])
				}
			}
		}
		if(i == 1) {
			contshareperstudy = list(i,contcum)
		}
		else{   
			contshareperstudy = cbind(contshareperstudy,list(i,contcum))
		}

	}
######## Step 2. specific study part for each study
	ntable <- matrix(0,ndata,3)
	for(i in 1:ndata){
		study = data.frame(read.table(famfiles[i], header= FALSE))
		cont = study[which(study[,6]==1),]
		case = study[which(study[,6]==2),]
		contname = cont[,1:2]	 
		contsharestudy = contshareperstudy[[(i*2)]]

		if(nrow(contsharestudy) == 0){
			print("no overlap in control samples")
			names(contname)=c("fid","iid")
			spestudycont=contname
		}
		else{
			names(contname)=c("fid","iid")
			names(contsharestudy)=c("fid","iid")
			contsharestudy$coder <- "share"
			contname$coder <- "spe"
			dfcont <- rbind(contname,contsharestudy)				
			dfcont <- dfcont[,c("fid","iid","coder")]						
			dupRowscont <- findDuplicate(dfcont,"coder")		
			spestudycont=(cbind(dfcont,dup=!dupRowscont))
			spestudycont=(spestudycont[which(spestudycont$dup=="TRUE"),])
			spestudycont=(spestudycont[which(spestudycont$coder=="spe"),])
			spestudycont=spestudycont[,!(names(spestudycont) %in% "dup")]
		}
		
		
		if(nrow(spestudycont)==0){
			print("all control samples are shared")
		}
		else{
			newdata = study[(paste(study[,1],study[,2]) %in% paste(spestudycont[,1],spestudycont[,2])),]
			write.table(rbind(case,newdata), file=paste("spe-",i,"-study-fold.ped",sep=""), quote=F, col.names=F, row.names=F)
		}
		if(i==1){	
			contspestudylist <- (list(i,spestudycont))
		}
		else{
			contspestudylist <- cbind(contspestudylist,(list(i,spestudycont)))
		}
	}
}



