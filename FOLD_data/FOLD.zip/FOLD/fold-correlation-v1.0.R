
######################################################
# fold-correlation.py
#  xxxx generate correlation matrix -> corr.table
# Eunji Kim (2016)
## Usage: read all.fam files in c("*.fam","**.fam",...etc)
## Additional information is available in manual
######################################################
FOLD.correlatioin = function(famfile){
	#1. generating correlation matrix 
	# input order famfile = logdata 
	ndata <- length(famfile)
	Rmatrix <- matrix(rep(0,ndata^2),ncol=ndata,nrow=ndata)
	for(i in 1:ndata)
	{
		study.i <- as.matrix(read.table(famfile[i],header=F))
		for(j in 1:ndata)
		{
			if(i != j){
				study.j <- as.matrix(read.table(famfile[j],header=F))
				case.study.j <- study.j[which(study.j[,6]==2),1]
				cont.study.j <- study.j[which(study.j[,6]==1),1]

				case.study.i <- study.i[which(study.i[,6]==2),1]
				cont.study.i <- study.i[which(study.i[,6]==1),1]

				ni1 <- length(case.study.i)
				ni0 <- length(cont.study.i)	
				nj1 <- length(case.study.j)
				nj0 <- length(cont.study.j)


				nij0 <- length(which(cont.study.i%in%cont.study.j))
				nij1 <- length(which(case.study.i%in%case.study.j))

				ni <- ni1+ni0
				nj <- nj1+nj0

				if((nij0==0)&(nij1==0)){
					Rmatrix[i,j]= 0
				}
				else if(nij0==0&(nij1!=0)){
					Rmatrix[i,j]= (nij1*sqrt((ni0*nj0)/(ni1*nj1)))/sqrt(ni*nj)
				}
				else if((nij0!=0)&(nij1==0)){
					Rmatrix[i,j]= (nij0*sqrt((ni1*nj1)/(ni0*nj0)))/sqrt(ni*nj)
				}
				else{
					Rmatrix[i,j]= (nij0*sqrt((ni1*nj1)/(ni0*nj0))+nij1*sqrt((ni0*nj0)/(ni1*nj1)))/sqrt(ni*nj)
				}	
			}
		}
	}

	write.table(Rmatrix,"corr.table", quote=F, col.names=F, row.names=F)

	print("Correlation matrix is generated: corr.table")
}



