######################################################
# fold-pvalue.py
#  xxxx read logistic output -> meta-analysis pvalue
# Eunji Kim (2016)
## Usage: read all.logistic files in c("...","....","...")
## Additional information is available in manual
######################################################
FOLD.pvalue = function(logdata){
	Rmatrix <- as.matrix(read.table("corr.table",header=F))
	invRmatrix <- solve(Rmatrix)
	result <- NULL
#########1.read logistic data and meta-analysis	
	nlogdata <- length(logdata)
	data <- (as.matrix(read.table(logdata[1],header=T)))
	nSNP <- nrow(data)
	logbeta <- matrix(0,nSNP,nlogdata)
	logstd <- matrix(0,nSNP,nlogdata)
	logbeta[,1] <- data[,7]
	logstd[,1] <- data[,8]
	for(l in 2:nlogdata){
		data <- as.matrix(read.table(logdata[l],header=T))	        
		logbeta[,l] <- data[,7]
		logstd[,l] <- data[,8]
	}

	for(k in 1:nSNP){
		chr <- data[k,1]
		snpname <- data[k,2]
		bp <- data[k,3]

		if(all(!is.na(logbeta[k,]))){
			combeta <- as.numeric((logbeta[k,]))
			comstd <- as.numeric((logstd[k,]))
			invstdmat <- solve(diag(comstd))
			invsigma <- invstdmat %*% invRmatrix %*% invstdmat
			unit <- t((rep(1,nlogdata)))
			invvar <- unit %*% invsigma %*% t(unit)
			beta_num <- unit %*% invsigma %*% (combeta)
			Linbeta <- beta_num/invvar
			Linvar <- 1/invvar
			Zscore <- (Linbeta/sqrt(Linvar))
			pvalue <- 2*pnorm(abs(Zscore),lower.tail=FALSE)
			result = rbind(result, c(chr,snpname,bp,pvalue))
		}
	}	   
	write.table(result, file="FE-meta.pvalue", quote=F, row.names=F, col.names=F)
}

